from flask import Flask, render_template, redirect, url_for, request
import mercadopago

app = Flask(__name__)

# Configurando a SDK do Mercado Pago com a chave de autenticação
sdk = mercadopago.SDK("APP_USR-1039031589021141-083016-42e7088c9468867a9864f5b93b03892a-1968082587")

# Função para gerar o link de pagamento
def gerar_link_pagamento(titulo, preco):
    payment_data = {
        "items": [
            {
                "id": "1",
                "title": titulo,
                "quantity": 1,
                "currency_id": "BRL",
                "unit_price": float(preco)
            }
        ],
        "back_urls": {
            "success": "http://127.0.0.1:5000/compracerta",
            "failure": "http://127.0.0.1:5000/compraerrada",
            "pending": "http://127.0.0.1:5000/compraerrada",
        },
        "auto_return": "all"
    }
    result = sdk.preference().create(payment_data)
    payment = result["response"]
    link_iniciar_pagamento = payment["init_point"]
    return link_iniciar_pagamento

# Rotas para páginas do menu principal
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/especialidades')
def especialidades():
    return render_template('especialidades.html')

@app.route('/tratamentos')
def tratamentos():
    return render_template('tratamentos.html')

@app.route('/CorpoClínico')
def corpo_clinico():
    return render_template('CorpoClínico.html')

@app.route('/contato')
def contato():
    return render_template('contato.html')

@app.route('/register_patient')
def register_patient():
    return render_template('register_patient.html')

@app.route('/register_doctor')
def register_doctor():
    return render_template('register_doctor.html')

@app.route('/apoin')
def apoin():
    return render_template('apoin.html')

@app.route('/historico')
def historico():
    return render_template('historico.html')

@app.route('/exames')
def exames():
    exames_disponiveis = [
        {"nome": "Hemograma Completo", "descricao": "Análise completa do sangue", "preco": 80.00},
        {"nome": "Raio-X", "descricao": "Imagem radiológica de alta precisão", "preco": 120.00},
        {"nome": "Ultrassonografia", "descricao": "Exame de imagem com ultrassom", "preco": 200.00},
        {"nome": "Ressonância Magnética", "descricao": "Exame de imagem por ressonância", "preco": 800.00},
        {"nome": "Eletrocardiograma", "descricao": "Monitoramento da atividade elétrica do coração", "preco": 150.00},
        {"nome": "Tomografia Computadorizada", "descricao": "Imagem detalhada por cortes do corpo", "preco": 700.00},
        {"nome": "Teste de Glicemia", "descricao": "Medição do nível de açúcar no sangue", "preco": 30.00},
        {"nome": "Exame de Urina", "descricao": "Análise bioquímica da urina", "preco": 40.00},
        {"nome": "Exame de Colesterol", "descricao": "Verificação dos níveis de colesterol", "preco": 50.00},
        {"nome": "Papanicolau", "descricao": "Detecção precoce de câncer cervical", "preco": 90.00},
        {"nome": "Triglicerídeos", "descricao": "Avaliação dos níveis de gordura no sangue", "preco": 90.00},
        {"nome": "Insulina", "descricao": "Análise de níveis de insulina no sangue", "preco": 110.00},
        {"nome": "Transaminases (TGO e TGP)", "descricao": "Avaliação da função hepática", "preco": 120.00},
        {"nome": "Hormônios da tireoide (TSH e T4 livre)", "descricao": "Monitoramento da saúde da tireoide", "preco": 130.00},
        {"nome": "Ureia e creatinina", "descricao": "Avaliação da função renal", "preco": 100.00},
        {"nome": "Exame de fezes", "descricao": "Detecção de parasitas e outros problemas digestivos", "preco": 65.00}
    ]
    return render_template("index.html", exames=exames_disponiveis)

@app.route('/pagar/<nome_exame>/<preco>')
def pagar(nome_exame, preco):
    link = gerar_link_pagamento(nome_exame, preco)
    return redirect(link)

@app.route('/compracerta')
def compracerta():
    return render_template('compracerta.html')

@app.route('/compraerrada')
def compraerrada():
    return render_template('compraerrada.html')

@app.route('/logout')
def logout():
    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
